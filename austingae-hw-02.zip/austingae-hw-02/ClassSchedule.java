/*--------------------------------------------------------------------------
GWU CSCI 1112 Fall 2022
author: Austin Gae

This class encapsulates the logic to model scheduling a set of classes for a university
--------------------------------------------------------------------------*/

public class ClassSchedule {
    /// Performs a deep copy of the input schedule and returns the deep copy.
    /// This operation might be used to make a permanent backup of the data
    /// as it would make a unique and unlinked copy of the data.
    /// @param schedule the schedule array to copy
    /// @return the deep copy of the schedule array that were copied
    public static String[][] clone(String[][] schedule) {
        /*schedule is an array of elements, and each element is an array of five elements: class department, class number, class title, class start time, class end time
        visualization: { {class department, class number, class title, class start time, class end time}, same , same , same};
        */

        /*
        String[][] classes;
        Iterate through every element in schedule array; and in every element,
        iterate through the class details and deep copy them into the String[][] classes.

        After completing the iteration, return the String[][] classes.
        */

        String[][] classes = new String[schedule.length][schedule[0].length];
        for (int classIndex = 0; classIndex < schedule.length; classIndex++) {
            for (int classDetailsIndex = 0; classDetailsIndex < schedule[classIndex].length; classDetailsIndex++) {
                classes[classIndex][classDetailsIndex] = schedule[classIndex][classDetailsIndex];
            }
        }

        return classes;
    }

    /// A referential copy (shallow copy of each row) and not an 
    /// element-wise copy (deep copy).  We are sorting elements with respect
    /// to the original data rather than generating a new set of data.
    /// @param schedule data containing the rows to reference
    /// @return an array containing a shallow copy of the input schedule 
    ///         rows
    public static String[][] createView(String[][] schedule) {
        // TODO : Implement Here
        String[][] classes = new String[schedule.length][schedule[0].length];

        for (int i = 0; i < schedule.length; i++) {
            classes[i] = schedule[i];
        }
        
        return classes;
    }
 
    //--------------------------------------------------------------------- 
    /// Compute the differential between start time (index 3) and end time 
    /// (index 4). The differential is not maintained in the data but is
    /// a virtual field derived by the calculation performed here
    /// @param classInfo a record from the scheduling data
    /// @return the difference in time between the end time and start time
    ///         in minutes
    public static int differential(String[] classInfo) {
        /*
            int startTime = duration(classInfo[3]);
            int endTime = duration(classInfo[4]);

            Then subtract: differential = endTime - startTime.
            Then return differential.
        */
        int startTime = duration(classInfo[3]);
        int endTime = duration(classInfo[4]);
        int differential = endTime - startTime;

        return differential;
    }

    //--------------------------------------------------------------------- 
    /// This utility function converts a time string from the "HH:mm:ss" 
    /// format into a value representing minutes
    /// @param time a string representing a time in "HH"mm:ss" format
    /// @return an integer representing the time converted to minutes
    private static int duration(String time) {
        String[] tokens = time.split(":");
        int h = Integer.parseInt(tokens[0]);
        int m = Integer.parseInt(tokens[1]);
        int t = h * 60 + m;
        return t;
    }

    //--------------------------------------------------------------------- 
    /// Performs a comparison between two classes that is equivalent to a 
    /// less than operation so that a sort can use this function to order 
    /// classes. The less than criteria is an evaluation between the 
    /// differentials of two classes.
    /// @param class1 a class record that is used as the "left" operand for
    ///        a less than comparison 
    /// @param class2 a class record that is used as the "right" operand for
    ///        a less than comparison 
    /// @return returns true if the computed differential for class1 is less
    ///         than the computed differential for class2; otherwise, 
    ///         returns false (false implies that differential for class1 is
    ///         greater than or equal to class2)
    public static boolean lessThan(String[] class1, String[] class2) {
        /*
        int differentialOfClass1 = differential(class1);
        int differentialOfClass2 = differential(class2);

        if differentialOfClass1 < differentialOfClass2 --> return true
        else if differentialOfClass1 > differentialOfClass2 --> return false
        */
        int differentialOfClass1 = differential(class1);
        int differentialOfClass2 = differential(class2);

        if (differentialOfClass1 < differentialOfClass2) {
            return true;
        }
        else if (differentialOfClass1 > differentialOfClass2 || differentialOfClass1 == differentialOfClass2) {
            return false;
        }

        return true;
    }
    //--------------------------------------------------------------------- 
    /// Swaps references to classes.  Note that this is a "shallow" swap and
    /// not a "deep" swap meaning we swap at a reference level (between rows
    /// in view) and not at the value level
    /// @param view A shallow copy of a set of classes 
    /// @param i the index of the first reference to swap
    /// @param j the index of the second reference to swap
    public static void swapClasses(String[][] view, int i, int j) {
        String[] temp = view[i];
        view[i] = view[j];
        view[j] = temp;
    }

    //--------------------------------------------------------------------- 
    /// Sorts (shallow) a set of references to classes in descending order 
    /// subject to the differential between ups and downs using selection 
    /// sort
    /// @param view A shallow copy of a set of classes 
    /// @return an array of profile information of 3 buckets with the 
    ///         respective buckets containing a count of 0: allocations, 
    ///         1:comparisons, and 2: swaps
    public static int[] sortSelection(String[][] view) {
        /*
        view = { {class department, class number, class title, class start time, class end time}, same , same , same};

        profile = {num. of allocations, num. of comparsions, num. of swaps};
        */

        // profile[0:allocs (ignore profile), 1:comparisons, 2:swaps]

        /*
        Functions To Use: 
        lessThan(String[] class1, String[] class2)
        swapClasses(String[][] view, int i, int j)

        for (i = 0; i < view.length-1; i++) {
            minimumIndex = i;

            for (j = i + 1; j < view.length; j++) {
                if (lessThan(view[j], view[minimumIndex])) {
                    minimumIndex = j;
                }
            }
 
            swapClasses(view, i, minimumIndex) 
            (
            ALSO THE SAME AS DOING THIS: 
            temp = view[i];
            view[i] = view[minimumIndex]
            view[minimumIndex] = view[i]
            )
        }
        */
        int[] profile = new int[3];
        profile[0] += 4;
        
        for (int i = 0; i < view.length-1; i++) {
            int minimumIndex = i;

            for (int j = i + 1; j < view.length; j++) {
                if (lessThan(view[j], view[minimumIndex])) {
                    minimumIndex = j;
                }
                profile[1] += 1; //after the comparsion of the if statement, add 1+ to profile[1], which is the index that sums up the number of comparsions
            }

            swapClasses(view, i, minimumIndex);
            profile[2] += 1; //after the swap occurs, add 1+ to profile[2], which is the index that sums up the number of swaps 
        }

        return profile;
    }

    //--------------------------------------------------------------------- 
    /// Sorts (shallow) a set of references to classes in descending order 
    /// subject to the differential between ups and downs using bubble 
    /// sort
    /// @param view A shallow copy of a set of classes 
    /// @return an array of profile information of 3 buckets with the 
    ///         respective buckets containing a count of 0: allocations, 
    ///         1:comparisons, and 2: swaps
    public static int[] sortBubble(String[][] view) {

        /*
        Functions To Use:
        lessThan(String[] class1, String[] class2)
        swapClasses(String[][] view, int i, int j)

        for (iteration = 1; iteration < view.length; iteration++) {
            for (j = 0; j < view.length - iteration; j++) {
                if (lessThan(view[j+1], view[j])) {
                    swapClasses(view, j+1, j)
                }
            }
        }
        */

        int[] profile = new int[3];
        profile[0] += 3;

        for (int iteration = 1; iteration < view.length; iteration++) {
            for (int j = 0; j < view.length - iteration; j++) {
                if (lessThan(view[j+1], view[j])) {
                    swapClasses(view, j+1, j);
                    profile[2] += 1; //after the swap occurs, add 1+ to profile[2]
                }
                profile[1] += 1; //after the comparsion has been made, add 1+ to profile[1]
            }
        }

        return profile;
    }

    //--------------------------------------------------------------------- 
    /// Sorts (shallow) a set of references to classes in descending order 
    /// subject to the differential between ups and downs using insertion 
    /// sort
    /// @param view A shallow copy of a set of classes 
    /// @return an array of profile information of 3 buckets with the 
    ///         respective buckets containing a count of 0: allocations, 
    ///         1:comparisons, and 2: swaps
    public static int[] sortInsertion(String[][] view) {
        /*
        Functions To Use:
        lessThan(String[] class1, String[] class2)
        swapClasses(String[][] view, int i, int j)

        for (index = 1; index < view.length - 1; index++) { 
            for (j = index; j > 0; j--) {
                if (lessThan(view[j], view[j-1])) {
                    swapClasses(view, j, j-1)
                }
                else {
                    break;
                }
            }
        }
        */

        int[] profile = new int[3];
        profile[0] += 3;

        for (int index = 1; index < view.length; index++) {
            for (int j = index; j > 0; j--) {
                profile[1] += 1;
                if (lessThan(view[j], view[j-1])) { //if ahead element < previous element, then swap the elements
                    swapClasses(view, j, j-1);
                    profile[2] += 1;
                }
                else {
                    break;
                }
            }
        }

        return profile;
    }

    //--------------------------------------------------------------------- 
    /// Sorts (shallow) a set of references to classes in descending order 
    /// subject to the differential between ups and downs using a quicksort.
    /// @param view A shallow copy of a set of classes 
    /// @return an array of profile information of 3 buckets with the 
    ///         respective buckets containing a count of 0: allocations, 
    ///         1:comparisons, and 2: swaps

    public static int partition(String[][] view, int left, int right, int[] profile) {
        /*
        partition(String[][] view, int left, int right) {
            //Set pivot as the last element 
            pivot = right;

            swapIndex = left - 1;

            //comparsion and swap (if necessary) with the element and pivot element occurs here.
            for (int i = left; i < right; i++) {
                if lessThan(view[i], view[pivot]) {
                    swapIndex++;

                    swapClasses(view, swapIndex, i)
                }
            }

            //at the very end, swap the pivot element with swapIndex + 1
            swapClasses(view, swapIndex+1, pivot)
        }
        */

        //set the pivot to the most right element index.
        int pivot = right;

        //set swapIndex to the most left element index - 1;
        int swapIndex = left - 1;

        //Compare and, if element < pivot element, call the swapClasses function.
        for (int i = left; i < right; i++) {
            profile[1] += 1;
            if (lessThan(view[i], view[pivot])) {
                swapIndex++;
                swapClasses(view, swapIndex, i);
                profile[2] += 1;
            }
        }

        //At the very end, when you get to the pivot element, call the swapClasses function to swap the pivot element with swapIndex+1 element. This will complete the partition of numbers less than the pivot element on the left side, and numbers greater than the pivot element on the right side. 
        swapClasses(view, swapIndex+1, pivot);
        profile[2] += 1;

        //return the index of the pivot element that has partitioned the numbers. 
        //this swapIndex+1 will be used in quickSortRecursive function.
        return swapIndex+1;


    }
    

    public static void quickSortRecursive(String[][] view, int left, int right, int[] profile) {
        /*
        quickSortRecursive(String[][] view, int left, int right) {
            if (left < right) {
                //partition() sorts the elements.
                int indexOfPartition = partition(view, left, right);

                //run quickSortRecursive again, which calls partition(), which will sort the elements to the left of the indexOfPartition
                quickSortRecursive(view, left, indexOfPartition-1);

                //run quickSortRecursive again, which calls partition(), which will sort the elements to the right of the indexOfPartition
                quickSortRecursive(view, indexOfPartition+1, right);
            }
        }
        */

        if (left < right) {
            int indexOfPartition = partition(view, left, right, profile);

            quickSortRecursive(view, left, indexOfPartition-1, profile);

            quickSortRecursive(view, indexOfPartition+1, right, profile);
        }
    }

    public static int[] sortQuicksort(String[][] view) {
        /*
        Functions To Use:
        lessThan(String[] class1, String[] class2)
        swapClasses(String[][] view, int i, int j)

        Recursion

        sortQuicksort(String[][] view) {
            quickSortRecursive(view, 0, view.length - 1);
        }
        */

        int[] profile = new int[3];
        profile[0] += 11;

        quickSortRecursive(view, 0, view.length-1, profile);

        return profile;
    }

}
